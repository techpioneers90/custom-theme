interface Element {
  msMatchesSelector(selectors: string): boolean;
}
